typedef J = Map<String, dynamic>;

final RegExp _dtcRe = RegExp(r'^[PCBU][0-3][0-9A-F]{3}$');

/// Kod biçimi geçerli mi (örn. P0401, U0100)?
bool isValidDtc(String code) => _dtcRe.hasMatch(code.trim().toUpperCase());

/// Veritabanında olmayan kodlar için ASLA hata vermeyen otomatik açıklama.
J fallbackDtc(String raw) {
  final code = raw.trim().toUpperCase();
  String title;
  String area;
  if (!isValidDtc(code) || code.length < 5) {
    title = 'Tanınmayan / Geçersiz Kod Biçimi';
    area = 'Kod biçimi standart OBD2 yapısına (örn. P0401) uymuyor. Kodu tekrar okuyun.';
  } else {
    final l = code[0], d = code[1];
    switch (l) {
      case 'P':
        if (d == '0') {
          title = 'Standart Güç Aktarma / Motor Arızası (P0xxx)';
          area = _pSub(code[2]);
        } else if (d == '1') {
          title = 'Üreticiye Özel Güç Aktarma / Motor Arızası (P1xxx)';
          area = 'Anlamı üreticiye göre değişir; markaya özel kod listesine bakın.';
        } else if (d == '2') {
          title = 'Motor / Emisyon Kontrol Arızası (P2xxx)';
          area = 'Genellikle standart (SAE) kod; enjeksiyon, turbo, DPF/EGR, NOx gibi sistemleri kapsar. Bazı P2xxx kodları üreticiye özeldir.';
        } else {
          title = 'Güç Aktarma Arızası (P3xxx)';
          area = 'Ayrılmış / üreticiye özel veya hibrit sistem kodu olabilir.';
        }
        break;
      case 'C':
        title = 'Şasi / ABS / ESP Sistemi Arızası (Cxxxx)';
        area = 'Fren, ABS, ESP, direksiyon veya süspansiyon sistemiyle ilgili.';
        break;
      case 'B':
        title = 'Gövde / Kabin Elektroniği Arızası (Bxxxx)';
        area = 'Hava yastığı, klima, kapı/cam, merkezi kilit gibi kabin sistemleri.';
        break;
      default:
        title = 'CAN-Bus Ağ İletişim Hatası (Uxxxx)';
        area = 'Kontrol üniteleri arası haberleşme; besleme, toprak, CAN hattı veya modül arızası olabilir.';
    }
  }
  return {
    'code': code,
    'title': title,
    'description':
        '$area Bu kod yerel veritabanında kayıtlı değil; kategori kod yapısından otomatik üretildi. Kesin tanım için "Google\'da Ara" veya "YouTube Videosu Bul" ile aracınıza özel bilgiye bakın.',
    'causes': [
      'Kodun anlamını araç marka/modeline göre doğrulayın',
      'İlgili sensör/aktüatör kablo ve soketlerini kontrol edin',
      'Sigorta, röle ve toprak bağlantılarını kontrol edin',
    ],
    'severity': 'Orta',
    'related_sensors': <String>[],
    'related_fuses': <String>[],
    'fallback': true,
  };
}

String _pSub(String c) {
  switch (c) {
    case '0':
    case '1':
    case '2':
      return 'Yakıt ve hava ölçümü ile ilgili.';
    case '3':
      return 'Ateşleme sistemi veya ateşleme kaçırma ile ilgili.';
    case '4':
      return 'Yardımcı emisyon kontrolü (EGR, EVAP, katalizör) ile ilgili.';
    case '5':
      return 'Hız, rölanti kontrolü ve yardımcı girişlerle ilgili.';
    case '6':
      return 'ECU / bilgisayar ve çıkış devreleriyle ilgili.';
    default:
      return 'Şanzıman ile ilgili.';
  }
}
