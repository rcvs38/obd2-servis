import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dtc_fallback.dart';
export 'dtc_fallback.dart' show J, isValidDtc;

/// Tüm ekranlar bu sınıf üzerinden 4 JSON dosyasından beslenir.
/// Araç/HSN-TSN değişince notifyListeners() tüm sayfaları günceller.
class AppState extends ChangeNotifier {
  bool loaded = false;
  String? error;
  late J _vehicles, _sensors, _dtcs, _fuses;

  String? brand;
  String? model;
  J? engine;
  final Set<String> activeCodes = {};

  Future<J> _read(String n) async =>
      jsonDecode(await rootBundle.loadString('assets/data/$n')) as J;

  Future<void> load() async {
    try {
      _vehicles = await _read('vehicles_db.json');
      _sensors = await _read('sensor_profiles.json');
      _dtcs = await _read('dtc_codes_tr.json');
      _fuses = await _read('fuses_db.json');
      loaded = true;
    } catch (e) {
      error = '$e';
    }
    notifyListeners();
  }

  // ---- Araç seçimi ----
  List<J> get brands => (_vehicles['brands'] as List).cast<J>();
  J? get brandData => brands.where((b) => b['name'] == brand).firstOrNull;
  List<J> get models => ((brandData?['models'] as List?) ?? []).cast<J>();
  J? get modelData => models.where((m) => m['name'] == model).firstOrNull;

  /// Seçili modelin yakıt tiplerine uyan motorlar.
  List<J> get engines {
    final fuels = ((modelData?['fuels'] as List?) ?? []).cast<String>();
    return ((brandData?['engines'] as List?) ?? [])
        .cast<J>()
        .where((e) => fuels.contains(e['fuel']))
        .where((e) => e['models'] == null || (e['models'] as List).contains(model))
        .toList();
  }

  void selectBrand(String? b) {
    brand = b; model = null; engine = null; notifyListeners();
  }
  void selectModel(String? m) {
    model = m; engine = null; notifyListeners();
  }
  void selectEngine(J? e) {
    engine = e; notifyListeners();
  }

  /// HSN (4) + TSN (3) ile araç bul; kba listesi vehicles_db.json'da doldurulmalıdır.
  bool selectByHsnTsn(String hsn, String tsn) {
    for (final b in brands) {
      for (final m in (b['models'] as List).cast<J>()) {
        for (final k in ((m['kba'] as List?) ?? []).cast<J>()) {
          if (k['hsn'] == hsn && k['tsn'] == tsn) {
            brand = b['name']; model = m['name'];
            final eid = k['engine_id'];
            final code = k['engine_code'];
            final all = (b['engines'] as List).cast<J>();
            engine = (eid != null
                    ? all.where((e) => e['id'] == eid).firstOrNull
                    : null) ??
                all.where((e) => e['code'] == code).firstOrNull;
            notifyListeners();
            return true;
          }
        }
      }
    }
    return false;
  }

  String get vehicleLabel => brand == null
      ? 'Araç seçilmedi'
      : [brand, model, engine?['name']].whereType<String>().join(' ');

  // ---- Sensör profilleri (Benzin / Dizel) ----
  String get fuelKey => engine?['fuel'] == 'Dizel' ? 'diesel' : 'petrol';
  String get fuelLabel => fuelKey == 'diesel' ? 'Dizel' : 'Benzin';
  List<J> sensors({List<String>? groups}) {
    var all = ((_sensors['profiles'][fuelKey]['sensors']) as List).cast<J>().toList();
    // Motora özel referans (ör. SH-VPTS): aynı key'i ezer, yeni key'leri ekler.
    for (final o in ((engine?['sensor_overrides'] as List?) ?? []).cast<J>()) {
      final i = all.indexWhere((x) => x['key'] == o['key']);
      if (i >= 0) {
        all[i] = o;
      } else {
        all.add(o);
      }
    }
    return groups == null ? all : all.where((s) => groups.contains(s['group'])).toList();
  }

  // ---- DTC ----
  List<J> get allDtcs => (_dtcs['codes'] as List).cast<J>();
  J? dtc(String code) =>
      allDtcs.where((d) => d['code'] == code.toUpperCase()).firstOrNull;
  /// Her kod için sonuç döner; veritabanında yoksa otomatik kategori üretir.
  J resolveDtc(String code) => dtc(code) ?? fallbackDtc(code);
  void addCode(String c) {
    final v = c.trim().toUpperCase();
    if (v.isEmpty) return;
    activeCodes.add(v);
    notifyListeners();
  }
  void removeCode(String c) { activeCodes.remove(c); notifyListeners(); }

  // ---- Sigorta ----
  /// Şablon + marka bilgisi + marka özel kayıtlar (overrides) birleştirilir.
  List<J> fuses(String box) {
    final tpl = ((_fuses['template'][box]) as List).cast<J>();
    final b = (_fuses['brands'] as Map)[brand] as J?;
    final mo0 = (b?['model_overrides'] as Map?)?[model] as J?;
    final mo = (mo0 != null &&
            (mo0['applies_to_fuel'] == null || mo0['applies_to_fuel'] == engine?['fuel']))
        ? mo0
        : null;
    final over = [
      ...(((mo?[box]) as List?)?.cast<J>() ?? <J>[]),
      ...(((b?['overrides']?[box]) as List?)?.cast<J>() ?? <J>[]),
    ];
    final overCats = over.map((o) => o['category']).toSet();
    return [...over, ...tpl.where((t) => !overCats.contains(t['category']))];
  }
  String get fuseNotice => (_fuses['verify_notice'] as String?) ?? 'Sigorta kutusu kapağındaki şemayı teyit edin.';
  String? get fuseModelNote {
    final b = (_fuses['brands'] as Map)[brand] as J?;
    return ((b?['model_overrides'] as Map?)?[model] as J?)?['note'] as String?;
  }
  String boxName(String box) =>
      ((_fuses['brands'] as Map)[brand] as J?)?['${box}_name'] ?? (box == 'engine_bay' ? 'Motor Bölümü Sigorta Kutusu' : 'Kabin Sigorta Kutusu');

  /// Aktif arıza koduna bağlı sigortalar kırmızı öne çıkar.
  bool isFuseFlagged(J fuse) {
    final prefixes = ((fuse['linked_dtc_prefixes'] as List?) ?? []).cast<String>();
    for (final c in activeCodes) {
      if (prefixes.any(c.startsWith)) return true;
      final d = dtc(c);
      if (d != null && ((d['related_fuses'] as List?) ?? []).contains(fuse['category'])) return true;
    }
    return false;
  }

  // ---- Arama linkleri (seçili araca göre) ----
  Future<void> search({required bool youtube, String extra = ''}) async {
    final v = brand == null ? '' : '$vehicleLabel ${engine?['code'] ?? ''}';
    final q = Uri.encodeQueryComponent('$v $extra'.trim());
    final url = youtube
        ? 'https://www.youtube.com/results?search_query=$q'
        : 'https://www.google.com/search?q=$q';
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }
}
