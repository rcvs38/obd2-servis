import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';

// ---------- Araç / HSN-TSN seçimi ----------
void showVehicleDialog(BuildContext context) {
  showDialog(context: context, builder: (_) => const _VehicleDialog());
}

class _VehicleDialog extends StatefulWidget {
  const _VehicleDialog();
  @override
  State<_VehicleDialog> createState() => _VehicleDialogState();
}

class _VehicleDialogState extends State<_VehicleDialog> {
  final hsn = TextEditingController(), tsn = TextEditingController();
  String? msg;
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return AlertDialog(
      title: const Text('Araç Seç'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<String>(
              value: s.brand, decoration: const InputDecoration(labelText: 'Marka'),
              items: [for (final b in s.brands) DropdownMenuItem(value: b['name'] as String, child: Text(b['name']))],
              onChanged: s.selectBrand),
            DropdownButtonFormField<String>(
              value: s.model, decoration: const InputDecoration(labelText: 'Model'),
              items: [for (final m in s.models) DropdownMenuItem(value: m['name'] as String, child: Text('${m['name']} (${m['years']})'))],
              onChanged: s.selectModel),
            DropdownButtonFormField<J>(
              value: s.engine, decoration: const InputDecoration(labelText: 'Motor'),
              items: [for (final e in s.engines) DropdownMenuItem(value: e, child: Text('${e['name']} • ${e['fuel']}'))],
              onChanged: s.selectEngine),
            const Divider(height: 32),
            Row(children: [
              Expanded(child: TextField(controller: hsn, maxLength: 4, decoration: const InputDecoration(labelText: 'HSN (4)'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: tsn, maxLength: 3, decoration: const InputDecoration(labelText: 'TSN (3)'))),
            ]),
            FilledButton(
                onPressed: () => setState(() => msg = s.selectByHsnTsn(hsn.text.trim(), tsn.text.trim())
                    ? 'Araç bulundu' : 'Eşleşme yok (kba listesini doldurun)'),
                child: const Text('HSN/TSN ile bul')),
            if (msg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(msg!)),
          ]),
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat'))],
    );
  }
}

// ---------- Sensör sayfaları ----------
class SensorListPage extends StatelessWidget {
  final List<String>? groups;
  final String title;
  const SensorListPage({super.key, required this.groups, required this.title});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (s.brand == null) return const _Hint('Önce üstten araç ve motor seçin.');
    if (s.engine == null) return const _Hint('Normal değer aralıkları için motor seçin.');
    final list = s.sensors(groups: groups);
    return ListView(padding: const EdgeInsets.all(12), children: [
      Text('$title — ${s.fuelLabel}', style: Theme.of(context).textTheme.titleLarge),
      for (final x in list) _SensorCard(x),
    ]);
  }
}

class _SensorCard extends StatefulWidget {
  final J s;
  const _SensorCard(this.s);
  @override
  State<_SensorCard> createState() => _SensorCardState();
}

class _SensorCardState extends State<_SensorCard> {
  double? v;
  @override
  Widget build(BuildContext context) {
    final x = widget.s;
    final min = (x['min'] as num).toDouble(), max = (x['max'] as num).toDouble();
    final ok = v == null ? null : (v! >= min && v! <= max);
    return Card(
      child: ListTile(
        title: Text(x['label']),
        subtitle: Text('Normal: $min – $max ${x['unit']}${x['note'] != null ? '\n${x['note']}' : ''}'),
        isThreeLine: x['note'] != null,
        trailing: SizedBox(
          width: 120,
          child: TextField(
            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
            decoration: InputDecoration(
              hintText: 'Ölçüm',
              suffixIcon: ok == null ? null : Icon(ok ? Icons.check_circle : Icons.cancel, color: ok ? Colors.green : Colors.red),
            ),
            onChanged: (t) => setState(() => v = double.tryParse(t.replaceAll(',', '.'))),
          ),
        ),
      ),
    );
  }
}

// ---------- DTC ----------
class DtcPage extends StatefulWidget {
  const DtcPage({super.key});
  @override
  State<DtcPage> createState() => _DtcPageState();
}

class _DtcPageState extends State<DtcPage> {
  final c = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return ListView(padding: const EdgeInsets.all(12), children: [
      Row(children: [
        Expanded(child: TextField(controller: c, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Arıza kodu ekle (ör. P0401)'))),
        IconButton(icon: const Icon(Icons.add), onPressed: () { if (c.text.isNotEmpty) s.addCode(c.text); c.clear(); }),
      ]),
      for (final code in s.activeCodes) _DtcTile(code),
      if (s.activeCodes.isEmpty) const _Hint('Kod ekleyin; ilgili sigortalar Sigorta sekmesinde kırmızı işaretlenir.'),
    ]);
  }
}

class _DtcTile extends StatelessWidget {
  final String code;
  const _DtcTile(this.code);
  Color _sev(String? v) => (v ?? '').startsWith('Yüksek') ? Colors.red : (v == 'Orta' ? Colors.orange : Colors.green);
  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    final d = s.resolveDtc(code);
    final fb = d['fallback'] == true;
    return Card(
      child: ExpansionTile(
        leading: Icon(fb ? Icons.help_outline : Icons.warning, color: _sev(d['severity'])),
        title: Text('$code — ${d['title']}'),
        subtitle: Text(fb ? 'Otomatik kategori (veritabanında yok)' : d['severity']),
        children: [
          Padding(padding: const EdgeInsets.all(12), child: Text(d['description'])),
          for (final n in (d['causes'] as List)) ListTile(dense: true, leading: const Icon(Icons.chevron_right), title: Text(n)),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            TextButton(onPressed: () => s.search(youtube: false, extra: '$code arıza kodu'), child: const Text("Google'da Ara")),
            TextButton(onPressed: () => s.search(youtube: true, extra: '$code arıza kodu'), child: const Text('YouTube Videosu Bul')),
            TextButton(onPressed: () => s.removeCode(code), child: const Text('Sil')),
          ]),
        ],
      ),
    );
  }
}

// ---------- Şanzıman / Fren ----------
class TransFrenPage extends StatelessWidget {
  const TransFrenPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = s.allDtcs.where((d) {
      final c = d['code'] as String;
      return c.startsWith('P07') || c.startsWith('C');
    }).toList();
    return ListView(padding: const EdgeInsets.all(12), children: [
      Text('Şanzıman (P07xx) ve ABS/ESP (C0xxx) kodları', style: Theme.of(context).textTheme.titleMedium),
      for (final d in list)
        Card(child: ListTile(
          title: Text('${d['code']} — ${d['title']}'),
          subtitle: Text(d['description']),
          trailing: IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => s.addCode(d['code'])),
        )),
    ]);
  }
}

// ---------- Sigorta ----------
class FusePage extends StatelessWidget {
  const FusePage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (s.brand == null) return const _Hint('Sigorta şeması için araç seçin.');
    return DefaultTabController(
      length: 2,
      child: Column(children: [
        TabBar(tabs: [Tab(text: s.boxName('engine_bay')), Tab(text: s.boxName('cabin'))]),
        Container(
          width: double.infinity,
          color: Colors.amber.shade900,
          padding: const EdgeInsets.all(8),
          child: Text('⚠ ${s.fuseNotice}${s.fuseModelNote != null ? '\n${s.fuseModelNote}' : ''}'),
        ),
        Expanded(child: TabBarView(children: [_FuseList('engine_bay'), _FuseList('cabin')])),
      ]),
    );
  }
}

class _FuseList extends StatelessWidget {
  final String box;
  const _FuseList(this.box);
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final fl = s.fuses(box);
    fl.sort((a, b) => (s.isFuseFlagged(b) ? 1 : 0) - (s.isFuseFlagged(a) ? 1 : 0));
    return ListView(children: [
      for (final f in fl)
        Card(
          color: s.isFuseFlagged(f) ? Colors.red.shade900 : null,
          child: ListTile(
            leading: Icon(s.isFuseFlagged(f) ? Icons.error : Icons.bolt, color: s.isFuseFlagged(f) ? Colors.white : null),
            title: Text('${f['fuse_no'] ?? '—'} — ${f['system']}'),
            subtitle: Text('${f['location']}\n${f['amperage']}'),
            isThreeLine: true,
          ),
        ),
    ]);
  }
}

class _Hint extends StatelessWidget {
  final String t;
  const _Hint(this.t);
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(t, textAlign: TextAlign.center)));
}
