import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import 'pages.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;
  static const _items = [
    (Icons.sensors, 'Sensörler'),
    (Icons.settings, 'Motor'),
    (Icons.battery_charging_full, 'Akü'),
    (Icons.build, 'Şanzıman/Fren'),
    (Icons.warning_amber, 'Arıza Kodları'),
    (Icons.electrical_services, 'Sigorta'),
  ];

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (!s.loaded) {
      return Scaffold(
          body: Center(child: s.error != null ? Text('Veri hatası: ${s.error}') : const CircularProgressIndicator()));
    }
    final pages = <Widget>[
      const SensorListPage(groups: null, title: 'Tüm Sensörler'),
      const SensorListPage(groups: ['engine', 'air_fuel', 'diesel'], title: 'Motor'),
      const SensorListPage(groups: ['battery'], title: 'Akü / Şarj'),
      const TransFrenPage(),
      const DtcPage(),
      const FusePage(),
    ];
    final wide = MediaQuery.of(context).size.width >= 800;
    return Scaffold(
      appBar: AppBar(
        title: InkWell(
            onTap: () => showVehicleDialog(context),
            child: Text(s.vehicleLabel, overflow: TextOverflow.ellipsis)),
        actions: [
          IconButton(icon: const Icon(Icons.directions_car), onPressed: () => showVehicleDialog(context)),
          IconButton(icon: const Icon(Icons.search), tooltip: 'Google', onPressed: s.brand == null ? null : () => s.search(youtube: false, extra: 'arıza sensör değerleri')),
          IconButton(icon: const Icon(Icons.ondemand_video), tooltip: 'YouTube', onPressed: s.brand == null ? null : () => s.search(youtube: true, extra: 'arıza tamiri')),
        ],
      ),
      body: Row(children: [
        if (wide)
          NavigationRail(
            selectedIndex: _i,
            labelType: NavigationRailLabelType.all,
            onDestinationSelected: (v) => setState(() => _i = v),
            destinations: [for (final e in _items) NavigationRailDestination(icon: Icon(e.$1), label: Text(e.$2))],
          ),
        Expanded(child: pages[_i]),
      ]),
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              selectedIndex: _i,
              onDestinationSelected: (v) => setState(() => _i = v),
              destinations: [for (final e in _items) NavigationDestination(icon: Icon(e.$1), label: e.$2)],
            ),
    );
  }
}
