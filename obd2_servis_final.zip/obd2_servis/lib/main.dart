import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app_state.dart';
import 'screens/home_shell.dart';

void main() {
  runApp(ChangeNotifierProvider(
    create: (_) => AppState()..load(),
    child: const ObdApp(),
  ));
}

class ObdApp extends StatelessWidget {
  const ObdApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'OBD2 Servis',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            colorSchemeSeed: Colors.indigo, useMaterial3: true, brightness: Brightness.dark),
        home: const HomeShell(),
      );
}
