import 'package:flutter_test/flutter_test.dart';
import 'package:obd2_servis/dtc_fallback.dart';

void main() {
  test('bilinmeyen kod için fallback üretir', () {
    expect(fallbackDtc('P1234')['title'], contains('P1xxx'));
    expect(fallbackDtc('u0999')['title'], contains('CAN'));
    expect(fallbackDtc('C1234')['title'], contains('ABS'));
    expect(fallbackDtc('B1234')['title'], contains('Kabin'));
    expect(fallbackDtc('???')['title'], contains('Geçersiz'));
    expect(fallbackDtc('')['fallback'], true);
  });
}
