# OBD2 Servis (Flutter - Windows & Android)

    1) Zip'i açın ve klasöre girin:   cd obd2_servis
    2) Platform dosyalarını üretin:   flutter create --platforms=windows,android --project-name obd2_servis .
    3) Çalıştırın:                    flutter pub get && flutter run -d windows   (Android: flutter run -d <cihaz>)

Gereksinim: Flutter 3.22+ (Dart 3.3+). Windows için Visual Studio "Desktop development with C++".
AndroidManifest.xml ve Windows CMake dosyaları 2. adımda Flutter tarafından üretilir.
Veri: assets/data/*.json. Sigorta kutusu kapağındaki şemayı her zaman teyit edin.

## GitHub Actions ile otomatik derleme
`.github/workflows/build.yml` her push'ta ve elle (Actions > Build OBD2 Servis > Run workflow) çalışır.
Sonuçlar çalışmanın sayfasında "Artifacts" bölümündedir: OBD2_Servis_Windows (zip) ve OBD2_Servis_Android (.apk).
